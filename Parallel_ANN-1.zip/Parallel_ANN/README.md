# Parallel_ANN
This repository is for our term project in parallelizing an artificial neural network using CUDA and MPI

Some Databases to consider:

- http://archive.ics.uci.edu/ml/datasets/Phishing+Websites

- http://archive.ics.uci.edu/ml/datasets/ISOLET

- http://archive.ics.uci.edu/ml/datasets/SUSY

